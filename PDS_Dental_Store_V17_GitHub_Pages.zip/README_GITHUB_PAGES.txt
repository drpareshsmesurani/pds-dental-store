PDS Dental Store V17 — GitHub Pages

This is the customer website prepared for GitHub Pages.
Supabase remains the database, authentication, product/order backend and storage.

Deploy:
1. Create a GitHub repository.
2. Upload index.html to the repository root.
3. Go to Settings → Pages.
4. Choose Deploy from a branch.
5. Select main and / (root), then Save.
6. Open the GitHub Pages URL shown there.

No Supabase database changes are required.

Security:
Never put Supabase service-role keys, Razorpay secrets, or other private secrets in index.html.
Manual UPI/QR payment can be added later.
