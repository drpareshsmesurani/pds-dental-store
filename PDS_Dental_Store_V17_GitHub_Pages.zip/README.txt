PDS Dental Store V16

Professional product detail and category presentation. Existing cart, wishlist, account, tracking, checkout and Supabase data flow preserved. Bulk purchase and Razorpay remain removed.
